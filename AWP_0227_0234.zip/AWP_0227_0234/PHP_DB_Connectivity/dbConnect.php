<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHP DB Connect</title>

    
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "newphp";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//sql to create table
$sql = " CREATE TABLE IF NOT EXISTS Cars (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(30) NOT NULL,
type VARCHAR(30) NOT NULL,
fuel VARCHAR(50),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if (mysqli_query($conn, $sql)) {
    echo "Table Cars created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}


// $sql = "INSERT INTO Cars (name, type, fuel)
// VALUES ('MERCEDES', 'Sedan', 'Diesel')";

// if ($conn->query($sql) === TRUE) {
//     echo "New record created successfully";
// } else {
//     echo "Error: " . $sql . "<br>" . $conn->error;
// }

$sql = "SELECT id, name, type FROM cars ";
$result = mysqli_query($conn, $sql);
echo "<br>";
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["id"]. " - Name: " . $row["name"]." Type:--->".$row["type"]."<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
?>
</body>
</html>