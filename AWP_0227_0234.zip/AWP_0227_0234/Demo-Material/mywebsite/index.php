<!DOCTYPE html>
<html>
    <head>
        <title>PHP Demo</title>
    </head>
    <body>
        <?php
         $my_name="John";
         $age = 39;
          echo 'Hello PHP!';
          echo $my_name;  

        $t = date('H');
        if($t <"20"){
            echo "ok ".$t;
        }

        $someColor = "red";
        switch($someColor){
                case "red":
                        echo "Your color is red";
                break;
                case "blue":
                        echo "The blue";
                break;
                default:
                    echo "no color";
        }
        $x = 1;
        while($x <10){
            echo "The number is ".$x." <br/>";
            $x++;
        } 
        $x = 1;
        do{
            echo "The number is ".$x." <br/>";
            $x++;
        }while($x<10);

        for($x=0;$x <= 10; $x++){
            echo "The number is ".$x." <br/>";
        }

        $colors = array("red","green","blue","yellow");
            foreach($colors as $value){
                echo "The color is ".$value." <br/>";
            }

        $age = array("Peter"=>"35","Ben"=>"37","Joe"=>"43");
            asort($age);    // sorts on basis of value
            ksort($age); // sorts on the basis of key
            arsort($age);
            krsort($age);
        // echo "Peter is ".$age['Peter']." years old";
        foreach($age as $x => $val){
            echo $x." =>".$val."<br/>";
        }

        ?>
    </body>
</html>