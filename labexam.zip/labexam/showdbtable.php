﻿<?php
    include("connection.php");
    $query = "SELECT * FROM cars";
    $result = mysqli_query($conn,$query);
    $total = mysqli_num_rows($result);
   // echo "$total";
    if($total!=0)
    {
?>
        <table>
            <tr>
                <td>number</td>
                <td>name</td>
                <td>type</td>
            </tr>
<?php
        while($data=mysqli_fetch_assoc($result))
        { 
            echo "<tr><td>".$data['number']."</td><td>".$data['name']."</td><td>".$data['type']."</td></tr>";
    
        }
    }
    else
    {
        echo "Table has no such data"; 
    }
?>

    <a href="login.php">logout</a>

</table>