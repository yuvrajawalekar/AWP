﻿<?php
include("connection.php");

?>

            <form action="" method="POST">
                username: <input type="text" name="username" value=""/><br/><br/>
                password: <input type="password" name="password" value=""/><br/><br/>
                <input type="submit" name = "submit" value="login"/><br/><br/>
            </form> 
    
<?php
if(isset($_POST['submit']))
{
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $query="select * from cars where user='$user' and password='$pass'";
    $data=mysqli_query($conn,$query);
    $total=mysqli_num_rows($data);
    
            if($total==1)
            {
               header('location:showdbtable.php');
            }
            else
            {
                echo "login failed";
            }
}

?>