﻿<?php
    include("connection.php");
    $query = "insert into cars values(5,'toyota','sedan')";
    $result = mysqli_query($conn,$query);
    if($result)
    {
        echo "Data inserted successfully";
    }
    else
    {
        echo "Data insertion failed";
    }
?>