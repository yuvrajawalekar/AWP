﻿<?php 
    $servername="localhost";
    $username="root";
    $password="";
    $dbname="phpexam";
    error_reporting(0);
    $conn = mysqli_connect($servername,$username,$password,$dbname); 
    
        if($conn)
        {
            echo "";
        }
        else
        {
            echo "Connection Failed";
        }
?>