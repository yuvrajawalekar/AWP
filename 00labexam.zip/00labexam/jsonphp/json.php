<?php
    $jsonobj=file_get_contents("jsonfile.json");
    $json=json_decode($jsonobj,true);

    //echo $json ['student'] [1] ['name'];

    echo "<h2>Student Details </h2>";
    $output="";
    foreach($json['student'] as $stu)
    {
        $output.="ID : ".$stu['id']."<br/>";
        $output.="ID : ".$stu['name']."<br/>";
        $output.="<br/>";
    }
    echo $output;
?>